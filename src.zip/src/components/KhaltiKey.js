let myKey = {
    publicTestKey: 'test_public_key_0e1cf205988d4124b151e7a0288cefa4',
    secretKey: 'test_secret_key_2aea424928e54810a454fc6e737acb67'
}
 
export default myKey;